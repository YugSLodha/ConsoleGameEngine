If On Running the game the game doesn't display properly,
try running it through command prompt
Open Command Prompt in the pong folder enter ".\pong"
and the game should run.
IF THERE ARE ANY OTHER ISSUES TELL ME IN THE ITCH IO PAGE
Thank You.